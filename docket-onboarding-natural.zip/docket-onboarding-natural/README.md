# The Docket — Getting Started video

A narrated onboarding walkthrough for developers, project managers, executives, and non-technical newcomers. Prepared against application commit `9cc28cf` on 2026-10-16. It includes the quiet note-save feedback and bottom-left Download tasks placement from the latest feature branch.

## Deliverables

- `the-docket-getting-started.mp4`: 1920×1080 H.264 video with English natural synthetic narration and burned-in captions; intended for normal video players and approved internal sharing.
- `index.html`: responsive local player with chapter jumps, speed selection, and download links. Run `node source/serve_preview.cjs` and open `http://127.0.0.1:59139/`, or place the complete player bundle on an approved web host with byte-range support; opening local HTML directly may restrict optional subtitle loading.
- `captions.srt` and `captions.vtt`: external subtitle files. MP4 already contains visible captions, so enabling an external track can duplicate the text.
- `transcript.md`: complete narration with scene timestamps.
- `storyboard.jpg`: overview of every authored scene.
- `poster.jpg`: video cover.
- `source/`: editable script, measured timeline, chapters, and the build tool.

## Content and provenance

The video explains first-time setup, `.env` location and variables, startup commands, connection troubleshooting, the six navigation destinations, Combined Work, presets, local autosave versus Jira writes, planning, reports, metrics, capacity views, exports, optional Team DB, and AI context. It describes benefits for developers, PMs, and executives without treating issue counts as a measure of individual performance.

Every interface image is an authored, simplified diagram with fictional data. No live Jira account, personal token, `.env` contents, or company database was accessed. Only the authored tutorial narration was sent to Runway to generate the replacement voice. Controls and names were checked against the application code; layouts are educational illustrations rather than pixel-exact screen recordings. Example host placeholders must be replaced with an approved Jira hostname.

English narration uses the conversational Niki synthetic voice, lowered by one semitone with tempo compensation to preserve speed and cadence. Measured scene durations, captions, chapters, and the player were retimed to the replacement audio. The original system-voice version is preserved in its separate folder. Caption phrase timing is estimated within each measured narration segment, not generated from word-level speech recognition. The original narration and diagram sources are editable for future revisions.

## Refreshing

Requirements already present on the authoring machine: Python 3 with Pillow and FFmpeg/FFprobe with H.264/AAC encoding. The included scene MP3s are reused without API access; generating replacement speech is a separate step. The application has no added dependencies and does not load this build tool.

1. Edit `source/scenes.json` for headings and step bullets. To change narration, also replace the matching numbered MP3 under `assets/audio/`.
2. Update corresponding diagram content in `source/build_video.py` if controls or layout change.
3. Run `python3 source/build_video.py all` using a Python environment with Pillow.
4. Inspect the storyboard, sample the narration, and verify captions, durations and the player. Recheck facts against the current application before sharing.

Generated `assets/` intermediates and `narration.wav` are local authoring files, not needed to play the MP4. The package includes the narrated scene MP3s for rebuilding; it omits WAV and frame intermediates. Manual SharePoint upload remains the user's approved sharing workflow; this video does not configure or publish to SharePoint.
