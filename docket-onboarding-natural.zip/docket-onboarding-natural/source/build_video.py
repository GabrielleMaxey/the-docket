"""Build Docket onboarding media using supplied voice clips, Pillow and FFmpeg."""
import argparse
import concurrent.futures
import json
import math
import re
import subprocess
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parent.parent
SOURCE = ROOT / 'source'
ASSETS = ROOT / 'assets'
FRAMES = ASSETS / 'frames'
AUDIO = ASSETS / 'audio'
for directory in (FRAMES, AUDIO):
    directory.mkdir(parents=True, exist_ok=True)
SCENES = json.loads((SOURCE / 'scenes.json').read_text())
W, H, FPS = 1920, 1080, 24
NAVY, BLUE, YELLOW = '#073956', '#0b78b9', '#fdd219'
INK, MUTED, PAPER, LINE = '#123449', '#52677a', '#f3f7fb', '#d7e3ee'
FONTDIR = Path('/System/Library/Fonts/Supplemental')
FONTS = {}

def font(size, bold=False, mono=False):
    key = (size, bold, mono)
    if key not in FONTS:
        name = 'Courier New.ttf' if mono else ('Arial Bold.ttf' if bold else 'Arial.ttf')
        FONTS[key] = ImageFont.truetype(str(FONTDIR / name), size)
    return FONTS[key]

def run(args):
    return subprocess.run([str(a) for a in args], check=True, capture_output=True, text=True).stdout

def duration(path):
    return float(run(['ffprobe', '-v', 'error', '-show_entries', 'format=duration', '-of', 'default=noprint_wrappers=1:nokey=1', path]).strip())

def wrap(text, size, width, bold=False, mono=False):
    lines = []
    for paragraph in text.split('\n'):
        line = ''
        for word in paragraph.split():
            candidate = (line + ' ' + word).strip()
            if font(size, bold, mono).getlength(candidate) <= width or not line:
                line = candidate
            else:
                lines.append(line)
                line = word
        lines.append(line)
    return lines

def words(draw, text, xy, size=32, fill=INK, width=800, bold=False, leading=1.25, mono=False):
    x, y = xy
    for line in wrap(text, size, width, bold, mono):
        draw.text((x, y), line, font=font(size, bold, mono), fill=fill)
        y += round(size * leading)
    return y

def box(draw, rect, fill='white', outline=LINE, radius=20, width=2):
    draw.rounded_rectangle(rect, radius=radius, fill=fill, outline=outline, width=width)

def label(draw, text, x, y, fill=BLUE, size=27):
    tw = int(font(size, True).getlength(text))
    box(draw, (x, y, x + tw + 34, y + 49), fill=fill, outline=fill, radius=12)
    draw.text((x+17, y+8), text, font=font(size, True), fill='white')
    return tw + 34

def button(draw, text, x, y, width=250, active=True):
    box(draw, (x,y,x+width,y+62), fill=BLUE if active else '#e6edf3', outline=BLUE if active else LINE, radius=12)
    words(draw, text, (x+22,y+15), 27, 'white' if active else '#778898', width=width-36, bold=True)

def field(draw, title, value, x, y, width=870, mono=False):
    words(draw, title, (x,y), 25, MUTED, width)
    box(draw, (x,y+37,x+width,y+104), radius=10)
    words(draw,value,(x+20,y+53),29,INK,width-35,mono=mono)

def card(draw, title, value, x, y, width=275, accent=BLUE, detail=''):
    box(draw, (x,y,x+width,y+155), radius=18)
    words(draw,title,(x+22,y+18),26,MUTED,width-40)
    words(draw,value,(x+22,y+57),47,accent,width-40,bold=True)
    if detail: words(draw,detail,(x+22,y+117),21,MUTED,width-40)

def cursor(draw,x,y):
    draw.ellipse((x-29,y-29,x+29,y+29),fill=YELLOW,outline='white',width=4)
    draw.polygon([(x-7,y-12),(x-7,y+17),(x+1,y+9),(x+8,y+22),(x+15,y+17),(x+8,y+4),(x+19,y+3)],fill=NAVY)

def panel(draw, title, tab='Task Management'):
    x,y,r,b = 740,220,1800,840
    box(draw,(x+8,y+12,r+8,b+12),fill='#e2eaf2',outline='#e2eaf2',radius=24)
    box(draw,(x,y,r,b),radius=24)
    draw.rounded_rectangle((x,y,r,y+83),radius=24,fill=NAVY)
    draw.rectangle((x,y+45,r,y+83),fill=NAVY)
    words(draw,'The Docket',(x+30,y+22),31,YELLOW,300,bold=True)
    words(draw,tab,(x+410,y+25),28,'white',600,bold=True)
    words(draw,title,(x+32,y+110),35,INK,960,bold=True)
    return x+32,y+175

def draw_mock(draw, scene, phase):
    kind=scene['kind']
    if kind in ('welcome','roles','support','navigation','finish'):
        x,y=740,240
        if kind == 'welcome':
            box(draw,(x,y,1800,835),fill=NAVY,outline=NAVY,radius=30)
            draw.ellipse((x+395,y+60,x+665,y+330),fill=YELLOW)
            words(draw,'D',(x+466,y+82),172,NAVY,250,bold=True)
            words(draw,'Your work, in focus.',(x+100,y+375),60,'white',900,bold=True)
            words(draw,'A guided start for every role',(x+100,y+470),33,'#cfe8f6',900)
        elif kind == 'roles':
            entries=[('DEVELOPER','Find the next action','Assigned work • local notes • Now / Next'),('PROJECT MANAGER','Coordinate the work','Workload • due dates • capacity'),('EXECUTIVE','Focus the conversation','Risks • ownership • decisions')]
            for i,(a,b,c) in enumerate(entries):
                yy=y+i*192
                box(draw,(x,yy,1800,yy+167),outline=BLUE if phase%3==i else LINE,width=4 if phase%3==i else 2)
                words(draw,a,(x+30,yy+20),24,BLUE,900,bold=True)
                words(draw,b,(x+30,yy+59),38,INK,900,bold=True)
                words(draw,c,(x+30,yy+113),27,MUTED,950)
        elif kind == 'navigation':
            entries=[('Task Management','Daily work'),('Metrics','Project health'),('Project Managers','Workload & capacity'),('Past Reports','Saved outputs'),('Chat','Optional assistance'),('Settings','Setup & preferences')]
            for i,(a,b) in enumerate(entries):
                xx=x+(i%2)*540; yy=y+(i//2)*196
                box(draw,(xx,yy,xx+515,yy+172),fill=NAVY if phase%6==i else 'white',outline=BLUE if phase%6==i else LINE)
                col='white' if phase%6==i else INK
                words(draw,a,(xx+25,yy+35),34,col,465,bold=True)
                words(draw,b,(xx+25,yy+103),28,'#cee6f4' if phase%6==i else MUTED,465)
        else:
            entries=scene['points'] if kind=='finish' else ['Get the approved project checkout','Use approved Node 22','Keep your Jira API token private','Ask support to help with setup']
            for i,item in enumerate(entries):
                yy=y+i*140
                box(draw,(x,yy,1800,yy+115),fill='white',outline=BLUE if phase%len(entries)==i else LINE)
                draw.ellipse((x+25,yy+29,x+75,yy+79),fill=BLUE)
                words(draw,str(i+1),(x+41,yy+35),29,'white',60,bold=True)
                words(draw,item,(x+100,yy+31),33,INK,910,bold=True)
        return
    tabs={'env':'Local setup','launch':'Local setup','troubleshoot':'Local setup','sites':'Settings','presets':'Settings','team':'Settings','metrics':'Metrics','pm':'Project Managers','exec':'Metrics','reports':'Past Reports','ai':'Chat'}
    titles={'env':'.env — example values only','launch':'Browser mode','troubleshoot':'Connection checklist','sites':'Jira sites','combined':'Combined Open Work','managed':'Combined Open Work','presets':'Epic & JQL presets','notes':'Notes for DEMO-101','planning':'Planning for DEMO-101','writes':'Review the shared action','my-metrics':'My Metrics','metrics':'Project metrics','pm':'Contributor capacity','exec':'Project summary','reports':'Saved reports','export':'Download tasks','team':'Team data','ai':'Choose your context'}
    x,y=panel(draw,titles[kind],tabs.get(kind,'Task Management'))
    if kind=='env':
        lines=['JIRA_BASE_URL=https://<approved-site>.atlassian.net','JIRA_EMAIL=<your-account-email>','JIRA_API_TOKEN=<your-private-token>']
        box(draw,(x,y,x+995,y+255),fill='#102e43',outline='#102e43',radius=14)
        for i,line in enumerate(lines):
            words(draw,line,(x+25,y+30+i*69),28,'#f4f8fc',955,mono=True)
        label(draw,'.env.example  →  .env',x,y+290)
        words(draw,'Placeholders only. Restart after changing configuration.',(x,y+370),29,MUTED,960)
        if phase%3==2: cursor(draw,x+920,y+185)
    elif kind=='launch':
        commands=[('1  Install once','npm install'),('2  Start browser mode','npm run dev:all'),('3  Open the page','http://localhost:5173')]
        for i,(a,b) in enumerate(commands):
            yy=y+i*130
            words(draw,a,(x,yy),25,MUTED,950)
            box(draw,(x,yy+36,x+995,yy+111),fill=NAVY,outline=BLUE if phase%3==i else NAVY,width=4,radius=12)
            words(draw,b,(x+24,yy+52),34,'white',940,mono=True)
        words(draw,'Keep the terminal running.',(x,y+414),29,BLUE,970,bold=True)
    elif kind=='troubleshoot':
        checks=['File: .env beside package.json','Variable: JIRA_API_TOKEN','Saved site: URL and email','Restart → Test connection']
        for i,item in enumerate(checks):
            yy=y+i*104
            box(draw,(x,yy,x+995,yy+84),fill='#eff7fb',outline=LINE,radius=12)
            words(draw,str(i+1),(x+22,yy+22),31,BLUE,60,bold=True)
            words(draw,item,(x+88,yy+25),30,INK,880,bold=True)
    elif kind=='sites':
        field(draw,'Display name','Demo Operations',x,y)
        field(draw,'Jira URL','https://<approved-site>.atlassian.net',x,y+123)
        field(draw,'Email','<your-account-email>',x,y+246)
        button(draw,'Test connection',x,y+370,280)
        label(draw,'Connected',x+314,y+376,fill='#15735a')
        cursor(draw,x+251,y+396)
    elif kind in ('combined','managed'):
        words(draw,'Selected sites:  [x] Demo Operations   [x] Demo Platform',(x,y),28,INK,990)
        button(draw,'Load open work',x,y+65,290)
        label(draw,'Managed tasks',x,y+150)
        label(draw,'List',x+292,y+150,fill='#708496')
        headers=['Jira site','Issue','Title','Flag']; widths=[225,175,385,160]
        rows=[['Operations','DEMO-101','Prepare release','Now'],['Platform','DEMO-202','Review API change','Next']]
        table(draw,x,y+220,headers,rows,widths,phase)
        if kind=='combined': cursor(draw,x+258,y+94)
    elif kind=='presets':
        field(draw,'Preset label','My open work',x,y)
        field(draw,'JQL — example search','assignee = currentUser() AND resolution = Unresolved',x,y+135,995,True)
        button(draw,'Add preset',x,y+270,245)
        label(draw,'My open work',x+310,y+277)
        words(draw,'Choose this preset in Task Management → Run JQL',(x,y+388),29,BLUE,960,bold=True)
    elif kind=='notes':
        box(draw,(x,y,x+995,y+224),fill='white',outline=BLUE,width=3,radius=12)
        words(draw,'Next step: confirm the release checklist.\nWaiting for a review from the platform team.',(x+24,y+25),33,INK,940)
        status=['','Saving…','Saved locally'][min(phase,2)]
        words(draw,status,(x,y+240),27,MUTED,970)
        button(draw,'Push note',x,y+310,230)
        words(draw,'Explicit action → Jira comment',(x+270,y+327),29,BLUE,700,bold=True)
        words(draw,'Quiet local feedback • navigation stays still',(x,y+414),28,MUTED,970)
    elif kind=='planning':
        field(draw,'Docket priority','P2',x,y,310)
        label(draw,'Flag',x+375,y)
        label(draw,'[x] Now',x+375,y+63)
        label(draw,'[ ] Next',x+580,y+63,fill='#708496')
        field(draw,'Decision note','Confirm review before starting deployment.',x,y+145,995)
        field(draw,'Planning destination','Local  ▾',x,y+276,500)
        button(draw,'Save to database',x+575,y+315,310)
    elif kind=='writes':
        entries=[('LOCAL','Notes autosave • personal To Dos','#eff7fb',BLUE),('JIRA','Status • assignee • Jira dates','#fff8dd','#8f6a00'),('JIRA','Push note • Attach files','#fff8dd','#8f6a00')]
        for i,(a,b,c,col) in enumerate(entries):
            yy=y+i*135
            box(draw,(x,yy,x+995,yy+111),fill=c,outline=c)
            label(draw,a,x+20,yy+29,fill=col)
            words(draw,b,(x+170,yy+36),31,INK,795,bold=True)
    elif kind in ('my-metrics','metrics','pm','exec'):
        if kind=='my-metrics':
            card(draw,'Open work','8',x,y,300)
            card(draw,'In progress','3',x+330,y,300)
            card(draw,'Due soon','2',x+660,y,300,accent='#9a6600')
            for i,title in enumerate(['Status Report','1:1 Prep','PWB Review']): button(draw,title,x+i*330,y+208,300)
            words(draw,'Example counts • review scope and completeness',(x,y+335),29,MUTED,970)
        elif kind=='pm':
            entries=[('Demo contributor A',5,8),('Demo contributor B',9,8),('Demo contributor C',3,6)]
            for i,(name,current,target) in enumerate(entries):
                yy=y+i*133
                words(draw,name,(x,yy),30,INK,700,bold=True)
                box(draw,(x,yy+50,x+775,yy+88),fill='#e8f0f7',outline='#e8f0f7',radius=12)
                box(draw,(x,yy+50,x+min(current/target,1)*775,yy+88),fill='#ba8322' if current>target else BLUE,outline=LINE,radius=12)
                words(draw,f'{current} / {target}',(x+810,yy+47),29,MUTED,170)
        elif kind=='exec':
            entries=[('RISK','Release review still open'),('OWNER','Demo Operations team'),('DECISION','Confirm reviewer and target date')]
            for i,(a,b) in enumerate(entries):
                yy=y+i*130
                label(draw,a,x,yy,fill=BLUE)
                words(draw,b,(x+220,yy+7),31,INK,760,bold=True)
        else:
            label(draw,'Project metrics',x,y)
            label(draw,'Individual contributors',x+309,y,fill='#708496')
            button(draw,'Refresh status',x+688,y-6,288)
            card(draw,'Open','18',x,y+90,300)
            card(draw,'Overdue','2',x+330,y+90,300,accent='#9a6600')
            card(draw,'Complete','12',x+660,y+90,300,accent='#15735a')
            words(draw,'Snapshot refreshed: demo timestamp',(x,y+285),29,MUTED,970)
            words(draw,'Use linked issues and contributors to investigate.',(x,y+356),29,BLUE,970,bold=True)
    elif kind=='reports':
        label(draw,'Combined Work',x,y)
        entries=[('Status Report','Reviewed weekly update'),('1:1 Prep','Priorities and support needed'),('Ad-hoc','Saved Chat reply')]
        for i,(a,b) in enumerate(entries):
            yy=y+85+i*107
            box(draw,(x,yy,x+995,yy+88),radius=10)
            words(draw,a,(x+20,yy+26),29,INK,300,bold=True)
            words(draw,b,(x+350,yy+28),27,MUTED,620)
    elif kind=='export':
        table(draw,x,y,['Issue','Local note','Flag'],[['DEMO-101','Confirm checklist','Now'],['DEMO-202','Review API','Next']],[220,560,215],phase)
        box(draw,(x,y+205,x+305,y+275),fill='white',outline=BLUE,radius=10,width=3)
        words(draw,'↓ Download tasks',(x+22,y+223),29,BLUE,285,bold=True)
        cursor(draw,x+275,y+241)
        words(draw,'Workbook tabs: Demo Operations | Demo Platform',(x,y+317),29,INK,970,bold=True)
        words(draw,'Local notes and latest Jira comment have separate columns.',(x,y+385),28,MUTED,970)
    elif kind=='team':
        words(draw,'[ ] Use team DB',(x,y),36,INK,970,bold=True)
        words(draw,'Team database is off. Local saving is available.',(x,y+80),31,MUTED,970)
        button(draw,'Refresh status',x,y+150,280)
        button(draw,'Save to team',x+318,y+150,280,False)
        box(draw,(x,y+255,x+995,y+426),fill='#fff8dd',outline='#e4c764',radius=15)
        words(draw,'Only when enabled without configuration:',(x+22,y+277),26,'#7b5b0b',940,bold=True)
        words(draw,'Team data not configured — set TEAM_PRIORITY_DATABASE_URL',(x+22,y+329),29,'#7b5b0b',940)
    elif kind=='ai':
        entries=['Selected presets','Loaded task results','Current metrics snapshot']
        for i,a in enumerate(entries):
            words(draw,'[x] '+a,(x,y+i*72),32,INK,970)
        field(draw,'Example question','What needs attention before the next review?',x,y+240,995)
        words(draw,'Selected context → configured AI provider',(x,y+382),29,BLUE,970,bold=True)

def table(draw,x,y,headers,rows,widths,phase):
    total=sum(widths)
    box(draw,(x,y,x+total,y+65+len(rows)*77),radius=10)
    draw.rectangle((x+1,y+1,x+total-1,y+64),fill='#eaf2f8')
    xx=x
    for a,w in zip(headers,widths):
        words(draw,a,(xx+14,y+17),25,INK,w-20,bold=True)
        xx+=w
    for i,row in enumerate(rows):
        yy=y+65+i*77
        if phase%len(rows)==i: draw.rectangle((x+2,yy,x+total-2,yy+76),fill='#f0f7fc')
        xx=x
        for a,w in zip(row,widths):
            words(draw,a,(xx+14,yy+24),25,INK,w-22)
            xx+=w
        draw.line((x,yy+76,x+total,yy+76),fill=LINE,width=1)

def base_image(scene,index,phase,progress):
    image=Image.new('RGB',(W,H),PAPER)
    draw=ImageDraw.Draw(image)
    draw.rectangle((0,0,W,14),fill=YELLOW)
    words(draw,'THE DOCKET',(120,67),32,NAVY,600,bold=True)
    words(draw,'GETTING STARTED  /  DEMO SCREENS',(1140,72),22,MUTED,710,bold=True)
    label(draw,scene['chapter'].upper(),120,154)
    yy=words(draw,scene['title'],(120,235),66,NAVY,550,bold=True,leading=1.12)
    yy=words(draw,scene['subtitle'],(120,yy+30),32,MUTED,540,leading=1.27)
    for i,point in enumerate(scene['points']):
        if yy>805: break
        draw.ellipse((121,yy+37,133,yy+49),fill=BLUE)
        yy=words(draw,point,(151,yy+26),29,INK,500,leading=1.22)
    draw_mock(draw,scene,phase)
    words(draw,f'{index+1:02d} / {len(SCENES):02d}',(120,886),24,MUTED,200,bold=True)
    words(draw,'Simplified interface • fictional data',(1260,886),23,MUTED,560)
    draw.rectangle((120,930,1800,936),fill='#dbe6f0')
    draw.rectangle((120,930,120+1680*progress,936),fill=BLUE)
    draw.rectangle((0,958,W,H),fill=NAVY)
    return image

def readable_caption(text):
    replacements = {
        'dot env dot example': '.env.example',
        'dot env dot text': '.env.txt',
        'dot env': '.env',
        'package dot json': 'package.json',
        'JIRA underscore API underscore TOKEN': 'JIRA_API_TOKEN',
        'npm run dev colon all': 'npm run dev:all',
        'npm run desktop colon dev': 'npm run desktop:dev',
        'localhost on port fifty one seventy three': 'localhost:5173',
        'J Q L': 'JQL',
        'one on one Prep': '1:1 Prep',
        'P W B Review': 'PWB Review',
        'Use team D B': 'Use team DB',
    }
    for before, after in replacements.items():
        text = text.replace(before, after)
    return text


def caption_lines(text):
    return wrap(text,36,1640)

def make_cues(text):
    sentences=re.findall(r'[^.!?]+[.!?]?',text)
    cues=[]
    for sentence in sentences:
        sentence=sentence.strip()
        while len(caption_lines(sentence))>2:
            parts=sentence.split()
            n=min(18,len(parts))
            while len(caption_lines(' '.join(parts[:n])))>2: n-=1
            # Prefer a natural punctuation break near the end of the chunk.
            candidates=[j+1 for j,w in enumerate(parts[:n]) if w.endswith((',', ';', ':')) and j>=8]
            if candidates: n=candidates[-1]
            cues.append(' '.join(parts[:n]))
            sentence=' '.join(parts[n:])
        if sentence: cues.append(sentence)
    return cues

def stamp(seconds, srt=False):
    ms=round(seconds*1000)
    h,rem=divmod(ms,3600000); m,rem=divmod(rem,60000); s,ms=divmod(rem,1000)
    return f'{h:02d}:{m:02d}:{s:02d}{"," if srt else "."}{ms:03d}'

def audio_scene(index):
    audio = AUDIO / f'{index:02d}.mp3'
    wav = AUDIO / f'{index:02d}.wav'
    if not audio.exists():
        raise FileNotFoundError(f'Missing narrated scene: {audio}. Use the included voice assets.')
    run(['ffmpeg','-y','-v','error','-i',audio,'-af','apad=pad_dur=0.7','-ar','48000','-ac','1',wav])
    return duration(audio), duration(wav)


def build_audio():
    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
        timings=list(pool.map(audio_scene,range(len(SCENES))))
    items=[]; offset=0
    for scene,(speech,total) in zip(SCENES,timings):
        items.append({**scene,'start':offset,'speechDuration':speech,'duration':total})
        offset+=total
    (SOURCE/'timeline.json').write_text(json.dumps(items,indent=2,ensure_ascii=False))
    concat=AUDIO/'concat.txt'; concat.write_text('\n'.join(f"file '{(AUDIO/f'{i:02d}.wav').as_posix()}'" for i in range(len(items))))
    run(['ffmpeg','-y','-v','error','-f','concat','-safe','0','-i',concat,'-c:a','pcm_s16le',ROOT/'narration.wav'])
    print(f'Narration ready: {offset:.1f}s ({offset/60:.2f} minutes)',flush=True)

def build_frames():
    timeline=json.loads((SOURCE/'timeline.json').read_text())
    total=sum(s['duration'] for s in timeline)
    frame_list=[]; captions=[]; srt=[]; vtt=['WEBVTT','']; transcript=['# The Docket — Getting Started','', 'Narrated walkthrough with captions. Synthetic demo screens; not a live Jira recording.','', f'Length: {total/60:.1f} minutes. Checked against application commit 9cc28cf (2026-10-16).','']
    cue_index=0
    for i,scene in enumerate(timeline):
        cues=make_cues(scene['narration'])
        # Phrase timing is estimated from spoken word lengths; these are not ASR word alignments.
        weights=[len(c.split())+0.7 for c in cues]
        speech=scene['speechDuration']; t=scene['start']
        transcript.extend([f"## {stamp(t).split('.')[0]} — {scene['title']}",'',readable_caption(scene['narration']),''])
        for j,(spoken_cue,weight) in enumerate(zip(cues,weights)):
            cue=readable_caption(spoken_cue)
            span=speech*weight/sum(weights)
            hold=span+(scene['duration']-speech if j==len(cues)-1 else 0)
            image=base_image(scene,i,j,(t+hold)/total)
            draw=ImageDraw.Draw(image)
            lines=caption_lines(cue)
            assert len(lines)<=2,(cue,lines)
            yy=978 if len(lines)==2 else 998
            for line in lines:
                tw=font(36).getlength(line)
                draw.text(((W-tw)/2,yy),line,font=font(36),fill='white')
                yy+=45
            filename=FRAMES/f'{i:02d}-{j:02d}.png'; image.save(filename,optimize=True)
            frame_list.extend([f"file '{filename.as_posix()}'",f'duration {hold:.6f}'])
            cue_index+=1
            captions.append({'text':cue,'startMs':round(t*1000),'endMs':round((t+span)*1000),'timestampMs':None,'confidence':None})
            srt.extend([str(cue_index),f'{stamp(t,True)} --> {stamp(t+span,True)}',cue,''])
            vtt.extend([f'{stamp(t)} --> {stamp(t+span)}',cue,''])
            t+=span
        # Clean keyframe for storyboard and cover inspection.
        base_image(scene,i,1,scene['start']/total).save(ASSETS/f'scene-{i+1:02d}.png')
        print(f"Frames: {i+1}/{len(timeline)} — {scene['title']}",flush=True)
    frame_list.append(frame_list[-2])
    (ASSETS/'frames.txt').write_text('\n'.join(frame_list)+'\n')
    (ROOT/'captions.json').write_text(json.dumps(captions,indent=2,ensure_ascii=False))
    (ROOT/'captions.srt').write_text('\n'.join(srt))
    (ROOT/'captions.vtt').write_text('\n'.join(vtt))
    (ROOT/'transcript.md').write_text('\n'.join(transcript))
    chapters=[]; previous=None
    for scene in timeline:
        if scene['chapter']!=previous:
            chapters.append({'title':scene['chapter'],'start':scene['start']})
            previous=scene['chapter']
    (SOURCE/'chapters.json').write_text(json.dumps(chapters,indent=2))
    # Storyboard overview preserves complete frames, including empty caption-safe area.
    sheet=Image.new('RGB',(1600,math.ceil(len(timeline)/4)*260),'#e8eef5')
    d=ImageDraw.Draw(sheet)
    for i,scene in enumerate(timeline):
        thumb=Image.open(ASSETS/f'scene-{i+1:02d}.png').resize((384,216))
        xx=(i%4)*400+8; yy=(i//4)*260+8
        sheet.paste(thumb,(xx,yy))
        d.text((xx,yy+220),f"{i+1:02d}  {scene['title'][:34]}",font=font(16,True),fill=INK)
    sheet.save(ROOT/'storyboard.jpg',quality=94)
    Image.open(ASSETS/'scene-01.png').save(ROOT/'poster.jpg',quality=94)
    print(f'{cue_index} captions and storyboard ready',flush=True)

def render():
    timeline=json.loads((SOURCE/'timeline.json').read_text())
    metadata=[';FFMETADATA1','title=The Docket — Getting Started','comment=Synthetic demonstration screens. Natural synthetic narration: Niki.']
    chapters=json.loads((SOURCE/'chapters.json').read_text())
    total=sum(s['duration'] for s in timeline)
    for i,ch in enumerate(chapters):
        end=chapters[i+1]['start'] if i+1<len(chapters) else total
        metadata.extend(['[CHAPTER]','TIMEBASE=1/1000',f"START={round(ch['start']*1000)}",f'END={round(end*1000)}',f"title={ch['title']}"])
    meta=ASSETS/'metadata.txt'; meta.write_text('\n'.join(metadata))
    command=['ffmpeg','-y','-v','warning','-f','concat','-safe','0','-i',ASSETS/'frames.txt','-i',ROOT/'narration.wav','-f','ffmetadata','-i',meta,'-map','0:v:0','-map','1:a:0','-map_metadata','2','-map_chapters','2','-vf',f'fps={FPS},format=yuv420p','-c:v','libx264','-preset','fast','-crf','21','-af','aresample=48000,asetrate=48000*0.943874312682,aresample=48000,atempo=1.059463094359,loudnorm=I=-16:TP=-1.5:LRA=7','-c:a','aac','-b:a','128k','-t',str(total),'-movflags','+faststart',ROOT/'the-docket-getting-started.mp4']
    run(command)
    print(f'Video ready: {ROOT / "the-docket-getting-started.mp4"}',flush=True)

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('phase',choices=['audio','frames','render','all'])
    phase=parser.parse_args().phase
    if phase in ('audio','all'): build_audio()
    if phase in ('frames','all'): build_frames()
    if phase in ('render','all'): render()
