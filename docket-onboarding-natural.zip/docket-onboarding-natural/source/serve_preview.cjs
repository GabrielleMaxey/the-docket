// Local preview server with byte ranges so video chapter seeking works.
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const mime = { '.html':'text/html; charset=utf-8', '.mp4':'video/mp4', '.jpg':'image/jpeg', '.vtt':'text/vtt; charset=utf-8', '.srt':'text/plain; charset=utf-8', '.md':'text/plain; charset=utf-8', '.zip':'application/zip', '.json':'application/json' };
http.createServer((request,response) => {
  if (!['GET','HEAD'].includes(request.method)) { response.writeHead(405); response.end(); return; }
  let urlPath;
  try { urlPath = decodeURIComponent(new URL(request.url,'http://localhost').pathname); }
  catch { response.writeHead(400); response.end(); return; }
  const file = path.resolve(root, '.' + (urlPath === '/' ? '/index.html' : urlPath));
  if (!file.startsWith(root + path.sep)) { response.writeHead(403); response.end(); return; }
  fs.stat(file, (error,stat) => {
    if (error || !stat.isFile()) { response.writeHead(404); response.end(); return; }
    const headers = { 'Content-Type':mime[path.extname(file)] || 'application/octet-stream', 'Accept-Ranges':'bytes', 'Cache-Control':'no-cache' };
    let start = 0, end = stat.size - 1, status = 200;
    if (request.headers.range) {
      const range = /^bytes=(\d*)-(\d*)$/.exec(request.headers.range);
      if (!range || (!range[1] && !range[2])) { response.writeHead(416,{'Content-Range':`bytes */${stat.size}`}); response.end(); return; }
      if (!range[1]) start = Math.max(0,stat.size - Number(range[2]));
      else { start = Number(range[1]); if (range[2]) end = Math.min(end,Number(range[2])); }
      if (start > end || start >= stat.size) { response.writeHead(416,{'Content-Range':`bytes */${stat.size}`}); response.end(); return; }
      status = 206;
      headers['Content-Range'] = `bytes ${start}-${end}/${stat.size}`;
    }
    headers['Content-Length'] = end - start + 1;
    response.writeHead(status,headers);
    if (request.method === 'HEAD') { response.end(); return; }
    const stream = fs.createReadStream(file,{start,end});
    stream.on('error',()=>response.destroy());
    response.on('close',()=>stream.destroy());
    stream.pipe(response);
  });
}).listen(59139,'127.0.0.1',()=>console.log('The Docket video preview: http://127.0.0.1:59139/'));
