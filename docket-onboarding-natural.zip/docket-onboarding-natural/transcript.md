# The Docket — Getting Started

Narrated walkthrough with captions. Synthetic demo screens; not a live Jira recording.

Length: 7.7 minutes. Checked against application commit 9cc28cf (2026-10-16).

## 00:00:00 — Meet The Docket

Welcome to The Docket: a workspace for Jira work, personal planning, and project updates. This guide covers setup and navigation for developers, project managers, and executives. All demonstration screens use fictional data.

## 00:00:14 — One workspace. Three perspectives.

Developers can focus on assigned work, notes, and next steps. Project managers can spot workload pressure, overdue items, and delivery risks. Executives can use reviewed summaries to identify decisions and support needed. Useful insights depend on current Jira information.

## 00:00:33 — Start with the right support

Docket currently runs from a project checkout, with no supported packaged installer. Technical users can follow the next steps. Others should ask their application owner or support team to prepare the checkout, approved Node version, and credentials. Follow company software policies.

## 00:00:51 — Prepare your connection

In the project folder, beside package.json, copy .env.example to .env. Keep the leading dot; do not name it .env.txt. Enter your approved Jira URL, account email, and personal token as JIRA_API_TOKEN. Keep credentials private and restart after changes.

## 00:01:15 — Launch in your browser

For the first setup, run npm install from the project folder. Then start browser mode with npm run dev:all, and open localhost:5173. Leave the terminal running while using Docket. Desktop development mode is also available with npm run desktop:dev, if your company permits Electron.

## 00:01:38 — Save and test your sites

Open Settings, then Jira sites. Add a clear label, the approved site URL, and your account email. Test the connection before saving. Up to five entries are supported, using the shared server API token. The Site menu changes your active entry. Opening an issue in Jira may still ask you to sign in separately.

## 00:01:59 — If connection fails

If the connection fails, confirm the file is named .env and sits in the folder you launched. Check the exact token variable and saved site email, then restart and test again. Missing package errors usually mean dependencies need installation. Non-technical users should ask support to help, without sharing their token.

## 00:02:20 — Know the six destinations

Task Management is for daily work. Metrics shows project and contributor health. Project Managers provides a capacity view. Past Reports keeps saved outputs. Chat provides optional AI assistance. Settings holds connections, presets, and preferences. Start with the pages relevant to your role.

## 00:02:40 — Open your assigned work

To see your open assignments across saved Jira entries, choose Combined Open Work inside Task Management. Select the entries you want, then click Load open work. It includes open issues assigned to the account saved for each entry. Check each site's load status; a failed or partial result does not represent your complete workload.

## 00:03:02 — Choose a useful view

Combined Work opens in Managed tasks, with one editable table and a Jira site column. Switch to List for a compact overview. Check the site when issue keys look similar. Use a saved search preset for team or project work beyond your own assignments.

## 00:03:19 — Reuse a saved search

A preset is a named saved search. Use team-provided presets without writing Jira Query Language, or JQL. Technical users can create custom searches in Settings. Choose a preset and run the query. Check the count loaded and use Load remaining for additional matching issues.

## 00:03:38 — Keep notes close to the task

Type notes beside the task. Docket saves note text locally as you work, with quiet feedback beside the editor. A longer save shows Saving; an error needs attention. Local autosave does not publish a Jira comment. Review your text, select the row, and use Push note when you are ready to post it to Jira.

## 00:03:59 — Make the next action clear

Use Docket priority to rank work, and choose either Now or Next in the Flag column to clarify immediate versus upcoming attention. These are planning signals, not changes to Jira priority. Open planning details for dates and decision notes. In Combined Work, check whether your planning destination is Local or Team before saving.

## 00:04:21 — Understand what changes Jira

Some actions update Jira directly, including status, assignee, and Jira date fields. Push note posts a comment; Attach files uploads files to the issue. Local notes and personal To Dos serve a different purpose. Before submitting shared updates, confirm the issue and site. If a write times out, check Jira before trying again.

## 00:04:44 — Use My Metrics to prepare

My Metrics summarizes work in view, including Combined Work. Review open work and capacity. With report generation configured, Status Report, 1:1 Prep, and PWB Review help prepare updates and performance review drafts. Check completeness, dates, and wording before saving or sharing.

## 00:05:04 — Look across the project

For a project view, open Metrics, select relevant presets, and refresh the status snapshot. Review project health, contributor workload, and upcoming or overdue work. Click linked issues or people to investigate in Task Management. The page uses a saved snapshot until refreshed, so check its age before treating it as today's picture.

## 00:05:27 — Find where help is needed

Configure Contributor Metrics and optional capacity targets in Settings, then open Project Managers. Compare workloads and discuss overdue, blocked, or stale work. Issue counts support planning conversations; they do not directly measure effort or individual performance.

## 00:05:45 — Lead with decisions and context

Executives can start with a current Metrics snapshot or a reviewed report. Focus on delivery risks, ownership, dates, and decisions needed. Ask about incomplete data or unusual counts. Docket organizes evidence; Jira detail and the people doing the work provide essential context.

## 00:06:05 — Keep your useful reports

Save useful generated reports and selected Chat replies to Past Reports. Combined Work reports have a separate archive scope. Saving does not automatically share a report with the team. Download a copy for meetings, following company information handling rules.

## 00:06:21 — Download a workbook

Below the Task Management results, choose Download tasks on the left. Select the saved Jira entries and export scope, review the preview, then download the workbook. Each entry gets its own sheet, with local notes separate from the latest Jira comment. You can upload the file to SharePoint or share it through your approved process.

## 00:06:42 — Team data is optional

Local saving works without a company database. Use team DB is off by default and applies across this running app. An administrator must configure PostgreSQL, run the migration, and restart the API before enabling shared use. Team actions remain unavailable without a working connection. Local notes are not automatically shared simply by enabling this option.

## 00:07:06 — Use AI with the right context

Chat and report generation are optional. Selected work and context go to the configured AI provider. Use approved providers and data, check what you include, and verify answers before acting. Main task, metrics, and planning workflows work without Chat.

## 00:07:24 — Your first-day checklist

Start by testing your Jira connection. Load assigned work and confirm sites and completeness. Add a local note, choose Now or Next, and review a current snapshot. Download an approved workbook when needed. Build a routine that fits your role.
